﻿using System;

namespace CapaModelo
{
    public class Sesion
    {
        public int CodigoSesion { get; set; }
        public int CodigoUsuario { get; set; }

        public string Token { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime? FechaFin { get; set; }

        public string Ip { get; set; }
        public string UserAgent { get; set; }

        public bool Activa { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
