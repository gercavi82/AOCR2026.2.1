﻿using System;

namespace CapaModelo
{
    public class Inspeccion
    {
        public int CodigoInspeccion { get; set; }
        public int CodigoSolicitud { get; set; }

        public DateTime FechaInspeccion { get; set; }
        public string Inspector { get; set; }
        public string Informe { get; set; }
        public string Resultado { get; set; } // APROBADO / RECHAZADO / EN_PROCESO

        public DateTime? FechaCierre { get; set; }

        // Auditoría
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }

        public string UpdatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }

        public string DeletedBy { get; set; }
        public DateTime? DeletedAt { get; set; }
    }
    public DateTime? FechaProgramada
    {
        get => FechaInspeccion;
        set
        {
            if (value.HasValue)
                FechaInspeccion = value.Value;
        }
    }

}
