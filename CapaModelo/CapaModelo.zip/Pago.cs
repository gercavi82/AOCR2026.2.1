﻿using System;

namespace CapaModelo
{
    public class Pago
    {
        public int CodigoPago { get; set; }
        public int CodigoSolicitud { get; set; }

        public decimal Monto { get; set; }
        public string TipoPago { get; set; }     // Transferencia, depósito, tarjeta…
        public string Estado { get; set; }       // PENDIENTE, VALIDADO, RECHAZADO

        public string RutaComprobante { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaActualizacion { get; set; }

        public string Observaciones { get; set; }

        // Auditoría
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
    }
}
