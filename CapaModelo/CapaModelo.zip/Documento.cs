﻿public string ExtensionArchivo
{
    get
    {
        if (string.IsNullOrWhiteSpace(NombreArchivo)) return string.Empty;
        return System.IO.Path.GetExtension(NombreArchivo);
    }
    set { /* setter opcional */ }
}

public string CreatedBy
{
    get => UsuarioRegistro;
    set => UsuarioRegistro = value;
}
