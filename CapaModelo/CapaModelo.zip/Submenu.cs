﻿using System;
using System.Collections.Generic;

namespace CapaModelo
{
    public class Submenu
    {
        public int Id { get; set; }
        public int? IdMenu { get; set; }
        public string CodigoSubmenu { get; set; }
        public string NombreSubmenu { get; set; }
        public string Descripcion { get; set; }
        public string Icono { get; set; }
        public string Ruta { get; set; }
        public int? OrdenVisualizacion { get; set; }
        public bool? EsVisible { get; set; }
        public bool? RequiereAutenticacion { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public int? UsuarioRegistro { get; set; }
        public int? UsuarioModificacion { get; set; }
        public bool? Activo { get; set; }

        // Navegación
        public virtual Menu Menu { get; set; }
        public virtual ICollection<Permiso> Permisos { get; set; }

        public Submenu()
        {
            Permisos = new HashSet<Permiso>();
        }
    }
}