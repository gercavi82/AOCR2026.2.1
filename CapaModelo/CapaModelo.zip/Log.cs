﻿using System;

namespace CapaModelo
{
    public class Log
    {
        public long Id { get; set; }
        public int? IdUsuario { get; set; }
        public string TipoAccion { get; set; } // Login, Logout, Crear, Editar, Eliminar, Consultar
        public string Modulo { get; set; }
        public string Entidad { get; set; }
        public int? IdEntidad { get; set; }
        public string Descripcion { get; set; }
        public string DatosAnteriores { get; set; } // JSON
        public string DatosNuevos { get; set; } // JSON
        public string IpUsuario { get; set; }
        public string Navegador { get; set; }
        public string SistemaOperativo { get; set; }
        public string Dispositivo { get; set; }
        public DateTime? FechaHora { get; set; }
        public string Nivel { get; set; } // Info, Warning, Error, Critical
        public string MensajeError { get; set; }
        public string StackTrace { get; set; }
        public bool? Exitoso { get; set; }

        // Navegación
        public virtual Usuario Usuario { get; set; }
    }
}