﻿using System;

namespace CapaModelo
{
    public class Checklist
    {
        public int Id { get; set; }
        public int? IdInspeccion { get; set; }
        public string CodigoChecklist { get; set; }
        public string Categoria { get; set; }
        public string Item { get; set; }
        public string Descripcion { get; set; }
        public string RequisitoNormativo { get; set; }
        public string Resultado { get; set; } // Conforme, No Conforme, No Aplica
        public string Observaciones { get; set; }
        public bool? EsCritico { get; set; }
        public string EvidenciaDocumental { get; set; }
        public int? OrdenVisualizacion { get; set; }
        public DateTime? FechaVerificacion { get; set; }
        public int? UsuarioVerificador { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public int? UsuarioRegistro { get; set; }
        public int? UsuarioModificacion { get; set; }
        public bool? Activo { get; set; }

        // Navegación
        public virtual Inspeccion Inspeccion { get; set; }
    }
}