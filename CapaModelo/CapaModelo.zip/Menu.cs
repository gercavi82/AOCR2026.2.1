﻿using System;
using System.Collections.Generic;

namespace CapaModelo
{
    public class Menu
    {
        public int Id { get; set; }
        public string CodigoMenu { get; set; }
        public string NombreMenu { get; set; }
        public string Descripcion { get; set; }
        public string Icono { get; set; }
        public string Ruta { get; set; }
        public int? OrdenVisualizacion { get; set; }
        public bool? EsVisible { get; set; }
        public bool? RequiereAutenticacion { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public int? UsuarioRegistro { get; set; }
        public int? UsuarioModificacion { get; set; }
        public bool? Activo { get; set; }

        // Navegación
        public virtual ICollection<Submenu> Submenus { get; set; }
        public virtual ICollection<Permiso> Permisos { get; set; }

        public Menu()
        {
            Submenus = new HashSet<Submenu>();
            Permisos = new HashSet<Permiso>();
        }
    }
}