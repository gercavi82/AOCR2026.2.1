﻿using System;

namespace CapaModelo
{
    public class Notificacion
    {
        public int Id { get; set; }
        public int? IdUsuarioDestino { get; set; }
        public int? IdUsuarioOrigen { get; set; }
        public string TipoNotificacion { get; set; } // Sistema, Alerta, Recordatorio, Mensaje
        public string Titulo { get; set; }
        public string Mensaje { get; set; }
        public string Prioridad { get; set; } // Baja, Normal, Alta, Urgente
        public string Categoria { get; set; } // Solicitud, Inspeccion, Pago, Documento, etc.
        public int? IdEntidadRelacionada { get; set; }
        public string TipoEntidadRelacionada { get; set; }
        public string Icono { get; set; }
        public string Color { get; set; }
        public string Enlace { get; set; }
        public bool? Leida { get; set; }
        public DateTime? FechaLectura { get; set; }
        public bool? Enviada { get; set; }
        public DateTime? FechaEnvio { get; set; }
        public string CanalEnvio { get; set; } // Sistema, Email, SMS
        public DateTime? FechaExpiracion { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public bool? Activo { get; set; }

        // Navegación
        public virtual Usuario UsuarioDestino { get; set; }
        public virtual Usuario UsuarioOrigen { get; set; }
    }
}