﻿using System;

namespace CapaModelo
{
    public class Rol
    {
        // Identificadores
        public int CodigoRol { get; set; }
        public int IdRol
        {
            get => CodigoRol;
            set => CodigoRol = value;
        }

        // Nombre y descripción
        public string Nombre { get; set; }
        public string NombreRol
        {
            get => Nombre;
            set => Nombre = value;
        }
        public string Descripcion { get; set; }

        // Estado lógico
        public string Estado { get; set; }
        public bool Activo
        {
            get => Estado == "ACTIVO";
            set => Estado = value ? "ACTIVO" : "INACTIVO";
        }

        // Auditoría
        public DateTime? CreatedAt { get; set; }
        public DateTime? FechaCreado
        {
            get => CreatedAt;
            set => CreatedAt = value;
        }

        public DateTime? UpdatedAt { get; set; }
        public DateTime? FechaModificado
        {
            get => UpdatedAt;
            set => UpdatedAt = value;
        }

        public string CreatedBy { get; set; }
        public string CreadoPor
        {
            get => CreatedBy;
            set => CreatedBy = value;
        }

        public string UpdatedBy { get; set; }
        public string ActualizadoPor
        {
            get => UpdatedBy;
            set => UpdatedBy = value;
        }
    }
}
