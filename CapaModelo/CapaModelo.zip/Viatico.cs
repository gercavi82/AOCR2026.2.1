﻿using System;

namespace CapaModelo
{
    public partial class Viatico
    {
        public int Id { get; set; }
        public int? IdInspeccion { get; set; }
        public int? IdInspector { get; set; }
        public string TipoGasto { get; set; } // Transporte, Alimentación, Hospedaje, Otros
        public string Descripcion { get; set; }
        public decimal? Monto { get; set; }
        public string Moneda { get; set; }
        public DateTime? FechaGasto { get; set; }
        public string LugarGasto { get; set; }
        public string NumeroComprobante { get; set; }
        public string TipoComprobante { get; set; } // Factura, Boleta, Recibo
        public string RutaComprobante { get; set; }
        public string Estado { get; set; } // Pendiente, Aprobado, Rechazado, Pagado
        public string ObservacionesAprobacion { get; set; }
        public DateTime? FechaAprobacion { get; set; }
        public int? UsuarioAprobador { get; set; }
        public DateTime? FechaPago { get; set; }
        public string NumeroOperacionPago { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public int? UsuarioRegistro { get; set; }
        public int? UsuarioModificacion { get; set; }
        public bool? Activo { get; set; }

        // Navegación
        public virtual Inspeccion Inspeccion { get; set; }
        public virtual Usuario Inspector { get; set; }
        public virtual Usuario UsuarioAprobadorNavigation { get; set; }
    }
    public partial class Viatico
    {
        public int CodigoViatico { get; set; }       // ✅ AGREGAR
        public int? CodigoInspeccion { get; set; }   // ✅ AGREGAR
        public int? CodigoTecnico { get; set; }      // ✅ AGREGAR
        public DateTime? FechaSolicitud { get; set; } // ✅ AGREGAR
        public string Concepto { get; set; }         // ✅ AGREGAR
        public DateTime? Fecha { get; set; }         // ✅ AGREGAR
        public string Tipo { get; set; }             // ✅ AGREGAR
        public string Comprobante { get; set; }      // ✅ AGREGAR
        public string Observaciones { get; set; }    // ✅ AGREGAR
        public decimal? MontoTransporte { get; set; } // ✅ AGREGAR
        public decimal? MontoAlimentacion { get; set; } // ✅ AGREGAR
        public decimal? MontoHospedaje { get; set; } // ✅ AGREGAR
        public decimal? OtrosGastos { get; set; }    // ✅ AGREGAR
        public decimal? MontoPagado { get; set; }    // ✅ AGREGAR

        // ... resto de propiedades
    }
}