﻿using System;

namespace CapaModelo
{
    public class Auditoria
    {
        public int IdAuditoria { get; set; }
        public string Entidad { get; set; }
        public string Accion { get; set; }
        public string Usuario { get; set; }
        public DateTime Fecha { get; set; }
        public string DatosPrevios { get; set; }
        public string DatosNuevos { get; set; }
    }
}
