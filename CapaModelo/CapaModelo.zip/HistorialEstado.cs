﻿using System;

namespace CapaModelo
{
    public class HistorialEstado
    {
        public int CodigoHistorial { get; set; }
        public int? CodigoSolicitud { get; set; }

        public string EstadoAnterior { get; set; }
        public string EstadoNuevo { get; set; }

        public int? CodigoUsuario { get; set; }
        public string Observaciones { get; set; }

        public DateTime? FechaCambio { get; set; }

        // Campo de apoyo cuando haces join con usuario (DAO lo llena)
        public string NombreUsuario { get; set; }
    }
}
