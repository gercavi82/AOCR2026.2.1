﻿using System;

namespace CapaModelo
{
    public class Permiso
    {
        public int Id { get; set; }
        public int? IdRol { get; set; }
        public int? IdMenu { get; set; }
        public int? IdSubmenu { get; set; }
        public bool? PuedeVer { get; set; }
        public bool? PuedeCrear { get; set; }
        public bool? PuedeEditar { get; set; }
        public bool? PuedeEliminar { get; set; }
        public bool? PuedeExportar { get; set; }
        public bool? PuedeAprobar { get; set; }
        public bool? PuedeRechazar { get; set; }
        public string PermisosEspeciales { get; set; } // JSON con permisos adicionales
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public int? UsuarioRegistro { get; set; }
        public int? UsuarioModificacion { get; set; }
        public bool? Activo { get; set; }

        // Navegación
        public virtual Rol Rol { get; set; }
        public virtual Menu Menu { get; set; }
        public virtual Submenu Submenu { get; set; }
    }
}