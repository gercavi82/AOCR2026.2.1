﻿using System;

namespace CapaModelo
{
    public class Observacion
    {
        public int Id { get; set; }
        public string TipoEntidad { get; set; } // Solicitud, Inspeccion, Documento, etc.
        public int? IdEntidad { get; set; }
        public string TipoObservacion { get; set; } // Comentario, Corrección, Aclaración
        public string Descripcion { get; set; }
        public string Severidad { get; set; } // Baja, Media, Alta, Crítica
        public string Estado { get; set; } // Pendiente, En Proceso, Resuelta, Rechazada
        public DateTime? FechaObservacion { get; set; }
        public DateTime? FechaRespuesta { get; set; }
        public DateTime? FechaCierre { get; set; }
        public int? UsuarioObservador { get; set; }
        public int? UsuarioResponsable { get; set; }
        public string Respuesta { get; set; }
        public string DocumentoSoporte { get; set; }
        public bool? RequiereAccionCorrectiva { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public int? UsuarioRegistro { get; set; }
        public int? UsuarioModificacion { get; set; }
        public bool? Activo { get; set; }

        // Navegación
        public virtual Usuario UsuarioObservadorNavigation { get; set; }
        public virtual Usuario UsuarioResponsableNavigation { get; set; }
    }
}