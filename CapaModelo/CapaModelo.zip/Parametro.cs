﻿using System;

namespace CapaModelo
{
    public class Parametro
    {
        public int CodigoParametro { get; set; }

        public string Clave { get; set; }
        public string Valor { get; set; }
        public string Descripcion { get; set; }
        public string Tipo { get; set; }
        public string Categoria { get; set; }

        public bool? Activo { get; set; }
    }
}
