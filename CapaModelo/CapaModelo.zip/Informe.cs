﻿using System;

namespace CapaModelo
{
    public class Informe
    {
        public int Id { get; set; }
        public int? IdInspeccion { get; set; }
        public string CodigoInforme { get; set; }
        public string TipoInforme { get; set; } // Preliminar, Final, Complementario
        public string Titulo { get; set; }
        public string Resumen { get; set; }
        public string ContenidoInforme { get; set; } // Texto completo o JSON
        public string Conclusiones { get; set; }
        public string Recomendaciones { get; set; }
        public DateTime? FechaEmision { get; set; }
        public DateTime? FechaAprobacion { get; set; }
        public int? InspectorElaborador { get; set; }
        public int? SupervisorAprobador { get; set; }
        public string Estado { get; set; } // Borrador, Revisión, Aprobado, Publicado
        public int? VersionInforme { get; set; }
        public string RutaArchivo { get; set; }
        public string HashArchivo { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public int? UsuarioRegistro { get; set; }
        public int? UsuarioModificacion { get; set; }
        public bool? Activo { get; set; }

        // Navegación
        public virtual Inspeccion Inspeccion { get; set; }
        public virtual Usuario Inspector { get; set; }
        public virtual Usuario Supervisor { get; set; }
    }
}