﻿using System;

namespace CapaModelo
{
    public partial class UsuarioRol
    {
        public int CodigoUsuarioRol { get; set; }  // Identificador único de la relación
        public int CodigoUsuario { get; set; }      // Identificador del usuario
        public int CodigoRol { get; set; }          // Identificador del rol asignado
        public DateTime FechaAsignacion { get; set; } // Fecha en que se asignó el rol

        // Constructor por defecto
        public UsuarioRol() { }

        // Constructor parametrizado
        public UsuarioRol(int codigoUsuario, int codigoRol)
        {
            CodigoUsuario = codigoUsuario;
            CodigoRol = codigoRol;
            FechaAsignacion = DateTime.Now; // Asigna la fecha actual al momento de la creación
        }
    }
}