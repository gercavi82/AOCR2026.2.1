﻿using System;

namespace CapaModelo
{
    public class Aeronave
    {
        public int Id { get; set; }
        public int? IdSolicitud { get; set; }
        public string Matricula { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string NumeroSerie { get; set; }
        public string TipoAeronave { get; set; }
        public int? AnioFabricacion { get; set; }
        public decimal? PesoMaximoDespegue { get; set; }
        public int? CapacidadPasajeros { get; set; }
        public int? CapacidadCarga { get; set; }
        public string TipoMotor { get; set; }
        public int? NumeroMotores { get; set; }
        public string Propietario { get; set; }
        public string Operador { get; set; }
        public string Estado { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public int? UsuarioRegistro { get; set; }
        public int? UsuarioModificacion { get; set; }
        public bool? Activo { get; set; }

        // Navegación
        public virtual SolicitudAOCR Solicitud { get; set; }
    }
}