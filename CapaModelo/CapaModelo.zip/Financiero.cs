﻿using System;

namespace CapaModelo
{
    public class Financiero
    {
        public int CodigoFinanciero { get; set; }
        public int? CodigoSolicitud { get; set; }

        // Tipo de movimiento (INGRESO / EGRESO)
        public string TipoMovimiento { get; set; }

        // Concepto o descripción
        public string Concepto { get; set; }

        // Monto del movimiento
        public decimal Monto { get; set; }

        // Fecha del movimiento
        public DateTime FechaMovimiento { get; set; }

        // Datos de pago
        public string MetodoPago { get; set; }
        public string NumeroComprobante { get; set; }
        public string Banco { get; set; }
        public string NumeroCuenta { get; set; }

        // Estado del movimiento (PENDIENTE, CONFIRMADO, ANULADO)
        public string Estado { get; set; }

        // Observaciones opcionales
        public string Observaciones { get; set; }

        // Auditoría
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string UpdatedBy { get; set; }

        // Datos provenientes del JOIN con Solicitud
        public string NombreOperador { get; set; }
        public string Nit { get; set; }

        // Datos de confirmación / anulación
        public DateTime? FechaConfirmacion { get; set; }
        public string ConfirmadoPor { get; set; }
        public DateTime? FechaAnulacion { get; set; }
        public string AnuladoPor { get; set; }
        public string MotivoAnulacion { get; set; }
    }
}
