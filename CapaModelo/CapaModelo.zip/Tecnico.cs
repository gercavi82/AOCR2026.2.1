﻿namespace CapaModelo
{
    public class Tecnico
    {
        public int CodigoTecnico { get; set; }
        public string NombreCompleto { get; set; }
        public string Especialidad { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }
        public bool Activo { get; set; }
    }
}
