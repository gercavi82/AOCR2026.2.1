﻿using System;

namespace CapaModelo
{
    public partial class Usuario
    {
        public int Id { get; set; }                    // Identificador único del usuario
        public string NombreUsuario { get; set; }
        public string Nombres { get; set; }            // Nombre del usuario
        public string Apellidos { get; set; }          // Apellido del usuario
        public string Email { get; set; }               // Correo electrónico del usuario
        public string Telefono { get; set; }            // Número de teléfono
        public string Contrasena { get; set; }          // Contraseña del usuario
        public DateTime FechaCreacion { get; set; }     // Fecha en que se creó el usuario
        public bool Activo { get; set; }                // Estado del usuario (activo/inactivo)

        // Constructor por defecto
        public Usuario() { }

        // Constructor parametrizado
        public Usuario(string nombres, string apellidos, string email, string telefono, string contrasena)
        {
            Nombres = nombres;
            Apellidos = apellidos;
            Email = email;
            Telefono = telefono;
            Contrasena = contrasena;
            FechaCreacion = DateTime.Now; // Establece la fecha de creación como la fecha actual
            Activo = true; // Por defecto, un nuevo usuario está activo
        }

        // Método para mostrar la información del usuario
        public override string ToString()
        {
            return $"Usuario: {Nombres} {Apellidos}, Email: {Email}, Activo: {Activo}";
        }
    }
}